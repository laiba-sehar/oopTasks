﻿using sortedUAMS.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sortedUAMS.UserI
{
    class UI
    {
        public static int Menu()
        {
            Console.Clear();
            int option;
            Console.WriteLine("1. ADD STUDENT. ");
            Console.WriteLine("2. ADD DEGREE PROGRAM. ");
            Console.WriteLine("3. GENERATE MERIT. ");
            Console.WriteLine("4. VIEW REGISTERED STUDENTS. ");
            Console.WriteLine("5. VIEW STUDENTS OF A SPECIFIC PROGRAM. ");
            Console.WriteLine("6. REGISTER SUBJECT FOR A SPECIFIC STUDENT. ");
            Console.WriteLine("7. CALCULATE FEES FOR ALL  REGISTERED STUDENTS. ");
            Console.WriteLine("8. EXIT. ");
            Console.WriteLine("--> ENTER YOUR OPTION: ");
            option = int.Parse(Console.ReadLine());
            return option;
        }

        public static Student takeInputForStudent(List<DegreeProgram> programList)
        {
            int size;
            List<DegreeProgram> preferences = new List<DegreeProgram>();
            Console.WriteLine("ENTER YOUR NAME: ");
            string name = Console.ReadLine();
            Console.WriteLine("ENTER YOUR AGE: ");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER YOUR FSC MARKS: ");
            double fscMarks = double.Parse(Console.ReadLine());
            Console.WriteLine("ENTER YOUR ECAT MARKS: ");
            double ecatMarks = double.Parse(Console.ReadLine());
            Console.WriteLine("AVAILABLE DEGREE PROGRAM: ");
            viewDegreeList(programList);
            Console.WriteLine("ENTER YOUR PREFERENCES: ");
            size = int.Parse(Console.ReadLine());
            for (int x = 0; x < size; x++)
            {
                string degName;
                bool flag = false;
                Console.WriteLine("ENTER DEGREE NAME: ");
                degName = Console.ReadLine();
                foreach (DegreeProgram dp in programList)
                {
                    if (degName == dp.degreeTitle && !(preferences.Contains(dp)))
                    {
                        preferences.Add(dp);
                        flag = true;
                    }


                }
                if (flag == false)
                {
                    Console.WriteLine("ENTER VALID DEGREE NAME. ");
                    x--;
                }
            }
            Student data = new Student(name, age, fscMarks, ecatMarks, preferences);
            return data;
        }




        public static void viewDegreeList(List<DegreeProgram> programList)
        {
            foreach (DegreeProgram dp in programList)
            {
                Console.WriteLine(dp.degreeTitle);
            }
        }

        public static void viewSubjects(Student s)
        {
            if (s.regDegree != null)
            {
                Console.WriteLine("SubCode\tSubType");
                foreach (Subject sub in s.regDegree.subjects)
                {
                    Console.WriteLine(sub.subjectCode + "\t\t" + sub.subjectType);
                }
            }
        }

        public static DegreeProgram takeInputForDegree()
        {

            Console.WriteLine("ENTER THE DEGREE TITLE: ");
            string degreeTitle = Console.ReadLine();
            Console.WriteLine("ENTER THE DURATION: ");
            float duration = float.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE SEATS AVAILABLE: ");
            int seats = int.Parse(Console.ReadLine());
            DegreeProgram d = new DegreeProgram(degreeTitle, duration, seats);
            Console.WriteLine("ENTER HOW MANY SUBJECTS TO ENTER: ");
            int size = int.Parse(Console.ReadLine());

            for (int i = 0; i < size; i++)
            {

                d.AddSubject(takeInputForSubject());

            }
            return d;
        }

        public static Subject takeInputForSubject()
        {
            string subjectCode;
            string subjectType;
            int creditHours;
            int subjectFee;

            Console.WriteLine("ENTER THE SUBJECT CODE: ");
            subjectCode = Console.ReadLine();
            Console.WriteLine("ENTER THE SUBJECT TYPE: ");
            subjectType = Console.ReadLine();
            Console.WriteLine("ENTER THE SUBJECT CREDIT HOURS: ");
            creditHours = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE SUBJECT FEES: ");
            subjectFee = int.Parse(Console.ReadLine());
            Subject s = new Subject(subjectCode, creditHours, subjectType, subjectFee);
            return s;
        }

        public static void printStudents(List<Student> studentList)
        {
            foreach (Student s in studentList)
            {
                if (s.regDegree != null)
                {
                    Console.WriteLine(s.name + " GOT ADMISSION IN " + s.regDegree.degreeTitle);
                }
                else
                {
                    Console.WriteLine(s.name + " DID NOT GET ADMISSION IN ANY PROGRAM ");
                }
            }
        }

        public static void regSubjects(Student s)
        {
            Console.WriteLine("ENTER HOW MANY SUBJECTS YOU WANT TO REGISTER: ");
            int count = int.Parse(Console.ReadLine());
            for (int x = 0; x < count; x++)
            {
                Console.WriteLine("ENTER THE SUBJECT CODE: ");
                string code = Console.ReadLine();
                bool flag = false;
                foreach (Subject sub in s.regDegree.subjects)
                {
                    if (code == sub.subjectCode && !(s.regSubject.Contains(sub)))
                    {
                        s.regStudentSubject(sub);
                        flag = true;
                        break;
                    }

                }
                if (flag == false)
                {
                    Console.WriteLine("ENTER VALID COURSE.");
                    x--;
                }
            }
        }

        public static void viewStudentsInDegreee(List<Student> studentList,string degName)
        {
            Console.WriteLine("NAME\tFSC\tECAT\tAGE");
            foreach (Student s in studentList)
            {
                if (s.regDegree != null)
                {
                    if (degName == s.regDegree.degreeTitle)
                    {
                        Console.WriteLine(s.name + "\t" + s.fscMarks + "\t" + s.ecatMarks + "\t" + s.age);
                    }
                }
            }
        }

        public static void viewRegisteredStudents(List<Student> studentList)
        {
            Console.WriteLine("NAME\tFSC\tECAT\tAGE");
            foreach (Student s in studentList)
            {
                if (s.regDegree != null)
                {
                    Console.WriteLine(s.name + "\t" + s.fscMarks + "\t" + s.ecatMarks + "\t" + s.age);
                }
            }
        }


    }
}
