﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sortedUAMS.BL
{
    public class Student
    {
        public string name;
        public int age;
        public double fscMarks;
        public double ecatMarks;
        public double merit;
        public List<DegreeProgram> preferences;
        public List<Subject> regSubject;
        public DegreeProgram regDegree;

        public Student(string name, int age, double fscMarks, double ecatMarks)
        {
            this.name = name;
            this.age = age;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;
        }

        public Student(string name, int age, double fscMarks, double ecatMarks, List<DegreeProgram> preferences)
        {
            this.name = name;
            this.age = age;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;
            this.preferences = preferences;
            regSubject = new List<Subject>();
        }

        public  void calculateMerit()
        {
            this.merit = (((fscMarks / 1100) * 0.45F) + ((ecatMarks / 400) * 0.55F)) * 100;
        }


        public bool regStudentSubject(Subject s)
        {
            int stCH = getCreditHours();
            if (regDegree != null && regDegree.isSubjectExists(s) && stCH + s.creditHours <= 9)
            {
                regSubject.Add(s);
                return true;
            }
            else
            {
                Console.WriteLine("A student cannot have more than 9 CH or Wrong Subject");
                return false;
            }
        }

        public int getCreditHours()
        {
            int creditHour = 0;
            foreach (Subject s in regSubject)
            {
                creditHour = creditHour + s.creditHours;
            }
            return creditHour;
        }

        public float calculateFee()
        {
            float fees = 0;
            if (regDegree != null)
            {
                foreach (Subject s in regSubject)
                {
                    fees = fees + s.subjectFee;
                }
            }
            return fees;
        }




        public Student()
        {

        }
    }
}
