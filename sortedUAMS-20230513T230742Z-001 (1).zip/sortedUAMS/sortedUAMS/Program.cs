﻿using sortedUAMS.BL;
using sortedUAMS.UserI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sortedUAMS
{
    public class Program
    {
        static List<Student> studentList = new List<Student>();
        static List<DegreeProgram> programList = new List<DegreeProgram>();

        static void Main(string[] args)
        {

            int option;
            do
            {

                option = UI.Menu();
                Console.Clear();
                if (option == 1)
                {
                    if (programList.Count > 0)
                    {
                        Student s = UI.takeInputForStudent(programList);
                        addIntoStudentList(s);
                    }

                    else if (option == 2)
                    {
                        DegreeProgram d = UI.takeInputForDegree();
                        addIntoDegreeList(d);
                        Console.ReadKey();
                    }

                    else if (option == 3)
                    {
                        List<Student> sortedStudentList = new List<Student>();
                        sortedStudentList = sortedStudents();
                        giveAdmissions(sortedStudentList);
                        UI.printStudents(studentList);
                        Console.ReadKey();
                    }

                    else if (option == 4)
                    {
                        UI.viewRegisteredStudents(studentList);
                        Console.ReadKey();
                    }

                    else if (option == 5)
                    {
                        Console.WriteLine("ENTER THE DEGREE NAME: ");
                        string name = Console.ReadLine();
                        UI.viewStudentsInDegreee(studentList,name);
                        Console.ReadKey();
                    }

                    else if (option == 6)
                    {
                        Console.WriteLine("ENTER THE STUDENT NAME: ");
                        string name = Console.ReadLine();
                        Student s = presentStudents(name);
                        if (s != null)
                        {
                            UI.viewSubjects(s);
                            UI.regSubjects(s);
                        }
                        Console.ReadKey();
                    }

                    else if (option == 7)
                    {
                        calculateFeeforAll();
                        Console.ReadKey();
                    }

                    else if (option == 8)
                    {
                        break;
                    }
                    Console.Clear();


                }
            } while (option != 8);
            Console.ReadKey();
        }

        public static void addIntoStudentList(Student s)
        {
            studentList.Add(s);
        }
        static void addIntoDegreeList(DegreeProgram d)
        {
            programList.Add(d);
        }

        static List<Student> sortedStudents()
        {
            List<Student> sortedStudentList = new List<Student>();
            foreach (Student s in studentList)
            {
                s.calculateMerit();
            }
            sortedStudentList = studentList.OrderByDescending(o => o.merit).ToList();
            return sortedStudentList;
        }
        static void giveAdmissions(List<Student> sortedstudentList)
        {
            foreach (Student s in sortedstudentList)
            {
                foreach (DegreeProgram d in s.preferences)
                {
                    if (d.seats > 0 && s.regDegree == null)
                    {
                        s.regDegree = d;
                        d.seats--;
                        break;
                    }
                }
            }
        }



        static Student presentStudents(string name)
        {
            foreach (Student s in studentList)
            {
                if (name == s.name && s.regDegree != null)
                {
                    return s;
                }
            }
            return null;
        }

        static void calculateFeeforAll()
        {
            foreach (Student s in studentList)
            {
                if (s.regDegree != null)
                {
                    Console.WriteLine(s.name + " HAS " + s.calculateFee() + " FEES ");
                }
            }
        }

        
    }
}
